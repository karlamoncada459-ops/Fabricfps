package dev.example.fpsclient.modules;

import net.minecraft.client.Minecraft;
import net.minecraft.client.CloudStatus;
import java.util.List;

public final class ModuleManager {
    private static final List<ClientModule> MODULES = List.of(
        new ClientModule("entity_optimizer", "Entity / Distance Optimizer",
                "Uses a lower client render distance while enabled.") {
            private int oldDistance = -1;
            @Override protected void onToggle(boolean enabled) {
                Minecraft mc = Minecraft.getInstance();
                if (mc.options == null) return;
                if (enabled) {
                    oldDistance = mc.options.renderDistance().get();
                    mc.options.renderDistance().set(Math.min(oldDistance, 8));
                } else if (oldDistance > 0) {
                    mc.options.renderDistance().set(oldDistance);
                    oldDistance = -1;
                }
            }
        },
        new ClientModule("particle_limiter", "Particle Limiter",
                "Disables client particle spawning while enabled.") {
            @Override protected void onToggle(boolean enabled) {
                // The ParticleEngine mixin applies the toggle at the particle insertion point.
            }
        },
        new ClientModule("fog_sky_optimizer", "Fog & Sky Optimizer",
                "Disables clouds for a simpler sky and lower rendering overhead.") {
            private CloudStatus oldCloudStatus = CloudStatus.FANCY;
            @Override protected void onToggle(boolean enabled) {
                Minecraft mc = Minecraft.getInstance();
                if (mc.options == null) return;
                if (enabled) {
                    oldCloudStatus = mc.options.cloudStatus().get();
                    mc.options.cloudStatus().set(CloudStatus.OFF);
                } else {
                    mc.options.cloudStatus().set(oldCloudStatus);
                }
            }
        }
    );
    private ModuleManager() {}
    public static void initialize() {}
    public static List<ClientModule> all() { return MODULES; }
    public static boolean enabled(String id) {
        return MODULES.stream().anyMatch(m -> m.id().equals(id) && m.isEnabled());
    }
}
