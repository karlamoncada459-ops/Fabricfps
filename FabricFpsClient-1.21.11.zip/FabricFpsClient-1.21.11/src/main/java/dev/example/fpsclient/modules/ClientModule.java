package dev.example.fpsclient.modules;

import dev.example.fpsclient.config.ConfigManager;

public abstract class ClientModule {
    private final String id, name, description;
    private boolean enabled;
    protected ClientModule(String id, String name, String description) {
        this.id = id; this.name = name; this.description = description;
    }
    public String id() { return id; }
    public String name() { return name; }
    public String description() { return description; }
    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled, true); }
    public void setEnabled(boolean value, boolean save) {
        if (enabled == value) return;
        enabled = value;
        onToggle(value);
        if (save) ConfigManager.save();
    }
    protected abstract void onToggle(boolean enabled);
}
