package dev.example.fpsclient;

import dev.example.fpsclient.gui.ClickGuiScreen;
import dev.example.fpsclient.modules.ModuleManager;
import dev.example.fpsclient.config.ConfigManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import com.mojang.blaze3d.platform.InputConstants;

public final class FpsClient implements ClientModInitializer {
    public static final String MOD_ID = "fpsclient";
    public static KeyMapping OPEN_GUI;

    @Override
    public void onInitializeClient() {
        ConfigManager.load();
        ModuleManager.initialize();
        OPEN_GUI = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.fpsclient.open_gui", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_GUI.consumeClick()) client.setScreen(new ClickGuiScreen());
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                drawContext.drawString(mc.font, "FPS: " + mc.getFps(), 6, 6, 0xFFFFFF, true);
            }
        });
    }
}
