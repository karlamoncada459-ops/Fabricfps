package dev.example.fpsclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import dev.example.fpsclient.modules.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("fpsclient.json");
    private ConfigManager() {}

    public static void save() {
        try {
            JsonObject json = new JsonObject();
            ModuleManager.all().forEach(m -> json.addProperty(m.id(), m.isEnabled()));
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) { GSON.toJson(json, writer); }
        } catch (Exception e) { System.err.println("[FPSClient] Could not save config: " + e.getMessage()); }
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        try (Reader reader = Files.newBufferedReader(FILE)) {
            JsonObject json = GSON.fromJson(reader, JsonObject.class);
            if (json == null) return;
            ModuleManager.all().forEach(m -> {
                if (json.has(m.id())) m.setEnabled(json.get(m.id()).getAsBoolean(), false);
            });
        } catch (Exception e) { System.err.println("[FPSClient] Could not load config: " + e.getMessage()); }
    }
}
