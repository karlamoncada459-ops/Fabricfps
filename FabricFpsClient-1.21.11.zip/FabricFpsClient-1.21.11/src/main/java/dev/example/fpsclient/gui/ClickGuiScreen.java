package dev.example.fpsclient.gui;

import dev.example.fpsclient.modules.ClientModule;
import dev.example.fpsclient.modules.ModuleManager;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class ClickGuiScreen extends Screen {
    private int panelX = 30, panelY = 40;
    private boolean dragging;
    private int dragOffsetX, dragOffsetY;
    private static final int PANEL_W = 260, HEADER_H = 28, ROW_H = 34;

    public ClickGuiScreen() { super(Component.literal("FPS Client")); }
    @Override public boolean isPauseScreen() { return false; }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int height = HEADER_H + ModuleManager.all().size() * ROW_H + 12;
        g.fill(panelX, panelY, panelX + PANEL_W, panelY + height, 0xEE171B25);
        g.fill(panelX, panelY, panelX + PANEL_W, panelY + HEADER_H, 0xFF303B55);
        g.drawString(font, "FPS CLIENT  •  OPTIMIZER", panelX + 10, panelY + 10, 0xFFFFFFFF);
        int y = panelY + HEADER_H + 7;
        for (ClientModule module : ModuleManager.all()) {
            boolean on = module.isEnabled();
            g.drawString(font, module.name(), panelX + 10, y + 2, 0xFFE8ECF5);
            g.drawString(font, on ? "ON" : "OFF", panelX + PANEL_W - 42, y + 2,
                    on ? 0xFF55E08A : 0xFFFF7777);
            g.fill(panelX + 8, y + 19, panelX + PANEL_W - 8, y + 20, 0x334FFFFF);
            y += ROW_H;
        }
        g.drawString(font, "Right Shift / Esc: close", panelX + 10, panelY + height - 12, 0xFF9AA4B8);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        if (mouseY >= panelY && mouseY <= panelY + HEADER_H &&
                mouseX >= panelX && mouseX <= panelX + PANEL_W) {
            dragging = true; dragOffsetX = (int) mouseX - panelX; dragOffsetY = (int) mouseY - panelY;
            return true;
        }
        int rowY = panelY + HEADER_H + 7;
        for (ClientModule module : ModuleManager.all()) {
            if (mouseY >= rowY && mouseY < rowY + ROW_H &&
                    mouseX >= panelX && mouseX <= panelX + PANEL_W) {
                module.toggle(); return true;
            }
            rowY += ROW_H;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging && button == 0) {
            panelX = Math.max(0, Math.min(width - PANEL_W, (int) mouseX - dragOffsetX));
            panelY = Math.max(0, Math.min(height - 50, (int) mouseY - dragOffsetY));
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }
    @Override public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false; return super.mouseReleased(mouseX, mouseY, button);
    }
    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose(); return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
